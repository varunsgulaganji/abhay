import { Component } from '@angular/core';


@Component({
  selector: 'app-caurosel',
  templateUrl: './caurosel.component.html',
  styleUrl: './caurosel.component.css'
})
export class CauroselComponent {
 
    
  
    
  
}



