import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutfooter',
  templateUrl: './aboutfooter.component.html',
  styleUrl: './aboutfooter.component.css'
})
export class AboutfooterComponent {

}
