import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutchoose',
  templateUrl: './aboutchoose.component.html',
  styleUrl: './aboutchoose.component.css'
})
export class AboutchooseComponent {

}
