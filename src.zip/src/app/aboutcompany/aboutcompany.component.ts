import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutcompany',
  templateUrl: './aboutcompany.component.html',
  styleUrl: './aboutcompany.component.css'
})
export class AboutcompanyComponent {

}
