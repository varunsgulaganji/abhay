import { Component } from '@angular/core';

@Component({
  selector: 'app-varun',
  templateUrl: './varun.component.html',
  styleUrl: './varun.component.css'
})
export class VarunComponent {
  // 
  
  // showMessage: boolean = true;

  // ngOnInit(): void {
  //   this.toggleMessage();
  // }

  // toggleMessage() {
  //   setInterval(() => {
  //     this.showMessage = !this.showMessage;
  //   }, 4000); 
  // }
}
