import { Component } from '@angular/core';

@Component({
  selector: 'app-home-me',
  templateUrl: './home-me.component.html',
  styleUrl: './home-me.component.css'
})
export class HomeMEComponent {

}
