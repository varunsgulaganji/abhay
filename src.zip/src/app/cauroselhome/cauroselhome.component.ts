import { Component } from '@angular/core';

@Component({
  selector: 'app-cauroselhome',
  templateUrl: './cauroselhome.component.html',
  styleUrl: './cauroselhome.component.css'
})
export class CauroselhomeComponent {

}
